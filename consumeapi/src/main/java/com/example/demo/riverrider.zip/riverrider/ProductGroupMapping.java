package com.example.demo.riverrider;

import lombok.Data;

@Data
public class ProductGroupMapping {
	private String product;
	private String productgroup;
	private String productdescription;

}
