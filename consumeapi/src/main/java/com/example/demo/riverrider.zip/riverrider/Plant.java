package com.example.demo.riverrider;

import lombok.Data;

@Data
public class Plant {
	private String plantCode;

}
